<?php return array('version' => '27c4ff5aa1a309c78a0c');
